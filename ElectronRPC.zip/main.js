const electron = require('electron') 
const app = electron.app 
const BrowserWindow = electron.BrowserWindow 
const {Tray, Menu} = require('electron')
const path = require('path')
const url = require('url')
const express = require('express');
const RPC = require("discord-rpc");
const client = new RPC.Client({ transport: 'ipc' });

var LASTSAVEDSONG = '' 
let mainWindow

client.login({ clientId: '522363739874525204' });

client.once('ready', ()=>{
	const appv = express();
	appv.use(express.json());
	appv.post("/", (request, response) => {
		
		let body = request.body;
		if(body.action == "nono"){
			
			if(!body.tab.title.includes("- YouTube Music")){
				response.sendStatus(200);
				return
			}
			if(LASTSAVEDSONG == body.tab.title.substring(0, 128).split("- YouTube")[0]){
				response.sendStatus(200);
				return;
			}
			LASTSAVEDSONG = body.tab.title.substring(0, 128).split("- YouTube")[0]  

			var startTimestamp = new Date();
			let presence = {
				state: '노래감상 중..',//body.state.substring(0, 128),
				details: body.tab.title.substring(0, 128).split("- YouTube")[0], 
				largeImageKey: 'google',
				largeImageText: body.tab.title.substring(0, 128).split("- YouTube")[0], 
				instance: true, 
				startTimestamp,
			}; 
			client.setActivity(presence);
		}
		response.sendStatus(200);
	});
	appv.listen(3000, () => console.log('Discord-Chrome-Presence is ready!'));
});

  
app.on('ready', () =>{
	let tray = null 
	tray = new Tray(path.join(__dirname,'Google.png'))
  const contextMenu = Menu.buildFromTemplate([ 
	{label: '종료하기', click () {
        app.quit()
    }},
    
  ])
  tray.setToolTip('Youtube Music RPC - 클릭하면 종료됨')
  tray.setContextMenu(contextMenu)
	 
})

 
